$(document).ready(function() {

  $('#call_to_action').on('click', function(){
    $('#sign_up').scrollTo(1000);
  });

  $("#DateCountdown").TimeCircles({
    "animation": "smooth",
    "bg_width": 0.2,
    "fg_width": 0.013333333333333334,
    "circle_bg_color": "#60686F",
    "time": {
      "Days": {
        "text": "Days",
        "color": "#3b83c0",
        "show": true
      },
      "Hours": {
        "text": "Hours",
        "color": "#3b83c0",
        "show": true
      },
      "Minutes": {
        "text": "Minutes",
        "color": "#3b83c0",
        "show": true
      },
      "Seconds": {
        "text": "Seconds",
        "color": "#3b83c0",
        "show": true
      }
    }
  });
});